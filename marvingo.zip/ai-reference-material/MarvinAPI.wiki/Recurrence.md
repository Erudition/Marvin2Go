Marvin handles recurring tasks/projects/events/time blocks in different ways, mostly for technical reasons.

# Recurring Tasks

Recurring tasks are created once per day when you run Marvin on one of your devices. How far into the future Marvin generates these recurring task instances depends on your settings. The client asks for permission from the server to create recurring tasks so that only one of your devices will create future recurring task instances. If cloud sync is disabled, then the recurring task instances are created without asking for permission.

Recurring task templates are stored in the database in the [RecurringTasks](https://github.com/amazingmarvin/MarvinAPI/wiki/Marvin-Data-Types#recurringtasks) collection.

## Echo Tasks (repeat after X days)

Echo tasks work differently in that the next instance is immediately created and scheduled when you complete or delete the current instance. The RecurringTask template has type="echo", and individual instances have `echo=true` and `echoId` set to the ID of the task that was completed/deleted. Just like other recurring task instances, they have `recurringTaskId` set to the ID of their RecurringTask template.

## Weekly Review

The Weekly Review strategy is implemented using recurring tasks. Instead of using a RecurringTasks template item, the weekly review checklist and day of week are stored in `profile.strategySettings.weeklyReview.checklist` and `profile.strategySettings.weeklyReview.day`. Then recurring task instances are generated as usual, and have `recurringTaskId="wr"`.

# Recurring Projects

Recurring projects work very similar to recurring tasks except that they are created on the day of recurrence instead of in the future. This is mostly historical (since previously projects couldn't be scheduled in Marvin, just tasks). Possibly this will be improved in the future so that future recurring project instances are generated but hidden in the master list until they are needed.

## Echo Projects (repeat after X days)

Echo projects work a bit differently than echo tasks since they aren't generated until the date when they should be echoed. When the last instance of the echo project is completed or deleted, `profile.echoOn.${recurringProjectTemplate._id}` is set to the date when the project should be echoed. Then when of your devices gets permission to generate recurring tasks on that date (or later), the new echo project instance is created.

# Pinned Tasks

Pinned tasks live in the Tasks collection with `isPinned=true`. Pinned tasks cannot themselves be scheduled. When you create a new task from the pinned task, it has `pinId` set to the ID of the pinned task and from then on behaves as a normal task.

# Saved Items

Saved item templates are documented [here](https://github.com/amazingmarvin/MarvinAPI/wiki/Marvin-Data-Types#saved-items). You can then load instances of tasks and projects from the templates. Loaded instances are not marked in any way and behave as normal tasks/projects!

# Recurring Events and Time Blocks

Recurring events can not currently be setup from within Marvin, but rather come from external calendars. If you try to import a recurring event as a task within Marvin, it will be loaded as a recurring event within Marvin. A single Event within the database shows up multiple times within your calendar (unlike recurring tasks within Marvin where each instance has its own item in the database). These events and time blocks have `recurrence` set to a calendar-specific recurrence pattern. For google calendar and apple calendar, this is a standard RRULE pattern, but for outlook this is a non-standard JSON format. You can delete individual instances, which uses the `cancelDates` lookup (`date => true`) to keep track of which instances were canceled, and you can edit individual instances, which uses the `exceptions` lookup (time blocks: `date => { etag, calData, title, time, duration }`, events: `date => { etag, calData, start, title length }) to store changes for changed instances.