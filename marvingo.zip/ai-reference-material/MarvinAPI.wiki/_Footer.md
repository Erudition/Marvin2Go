&copy; 2020-2023 Amazing GmbH<br />
Use of Amazing Marvin's API falls under our [T&amp;C](https://amazingmarvin.com/terms/)<br />
All documentation text is licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/)