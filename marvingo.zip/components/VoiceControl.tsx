// This component is deprecated and replaced by the new UI layout in App.tsx
export const VoiceControl = () => null;
